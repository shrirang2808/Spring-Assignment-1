package com.spring2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}
	@Bean 
	public Book book() {
		return new Book("Verity","Cooleen Hoover");
	}
	
	@Bean
	public Student student() {
		return new Student("Shrirang",23);
	}
	
	@Bean
	public Library library(Book book) {
		Library library=new Library();
		library.setbook(book);
		return library;
	}
	
	@Bean
	public Classroom classroom(Student student) {
		return new Classroom(student);
	}

}
